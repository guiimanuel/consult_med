const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const Paciente = require("../models/paciente.model");
const Medico = require("../models/medico.model");
const Agendamento = sequelize.define("agendamento", {
    id:{
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_paciente: {
        type: DataTypes.INTEGER,
        uniqueKey: true,
        foreignKey: true,
        allowNull: false
    },
    cpf_paciente: {
        type: DataTypes.STRING,
        uniqueKey: true,
        foreignKey: true,
        allowNull: false
    },
    nome_paciente: {
        type: DataTypes.STRING,
        foreignKey: true,
        allowNull: false
    },
    hora_inicio: {
        type: DataTypes.DATE,
        allowNull: false
    },
    nome_medico:{
        type: DataTypes.STRING,
        allowNull: false,
        foreignKey: true
    },
    especializacao: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    timestamps: false
});
Agendamento.belongsTo(Medico, { foreignKey:"nome_medico", targetKey: "nome" });
Agendamento.belongsTo(Paciente, { foreignKey:"nome_paciente", targetKey: "paciente" });
Agendamento.belongsTo(Paciente, { foreignKey:"cpf_paciente", targetKey: "cpf" });
Agendamento.belongsTo(Paciente, { foreignKey:"id_paciente", targetKey: "id" });
module.exports = Agendamento;