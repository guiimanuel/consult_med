const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const Cirurgia = sequelize.define("cirurgia", {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    id_paciente:{
        type: DataTypes.INTEGER,
        allowNull: false
        
    },
    nome_paciente: {
        type: DataTypes.STRING,
        allowNull: false
        },
    tipo_cirurgia: {
        type: DataTypes.STRING,
        allowNull: false
    },
    data_cirurgia: {
        type: DataTypes.DATE,
        allowNull: false
    }
}, 
{
    timestamps: false
});
module.exports = Cirurgia;