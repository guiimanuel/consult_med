# hospital_med

Programa com função de solucionar o problema de Hospital médico com pacientes, médicos, agendamento de consultas, cirurgias, banco de sangue e internamentos.<br>

// Falta do node_modules (presente no arquivo zipado).
